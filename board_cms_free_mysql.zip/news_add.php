<?php
// news_add.php — Додавання новин/подій з фото, геолокацією та вибором мови зверху
// Повністю перекладено на 3 мови (ua/en/no)
// Оновлено: 30 грудня 2025 року

require_once 'config.php';

// Переклад заголовка сторінки
$title_page = [
    'ua' => 'Додати новину / подію',
    'en' => 'Add News / Event',
    'no' => 'Legg til nyhet / arrangement'
][$current_lang];

// Переклад помилок та успіху
$title_required = [
    'ua' => 'Вкажіть заголовок новини',
    'en' => 'Enter the news title',
    'no' => 'Angi nyhetstittel'
][$current_lang];

$description_required = [
    'ua' => 'Вкажіть опис новини / події',
    'en' => 'Enter the news/event description',
    'no' => 'Angi beskrivelse av nyhet / arrangement'
][$current_lang];

$photo_upload_error = [
    'ua' => 'Не вдалося завантажити фото',
    'en' => 'Failed to upload photo',
    'no' => 'Kunne ikke laste opp bilde'
][$current_lang];

$photo_format_error = [
    'ua' => 'Дозволені формати фото: jpg, jpeg, png, gif',
    'en' => 'Allowed photo formats: jpg, jpeg, png, gif',
    'no' => 'Tillatte bildeformater: jpg, jpeg, png, gif'
][$current_lang];

$news_success = [
    'ua' => 'Новину успішно додано! Дата публікації встановлена автоматично. Вона з’явиться після модерації.',
    'en' => 'News successfully added! Publication date set automatically. It will appear after moderation.',
    'no' => 'Nyhet lagt til! Publiseringsdato satt automatisk. Den vil vises etter moderering.'
][$current_lang];

$db_error_text = [
    'ua' => 'Помилка бази даних: ',
    'en' => 'Database error: ',
    'no' => 'Databasefeil: '
][$current_lang];

$locating = [
    'ua' => 'Визначення місця...',
    'en' => 'Locating...',
    'no' => 'Finne plassering...'
][$current_lang];

$location_determined = [
    'ua' => 'Місце визначено',
    'en' => 'Location determined',
    'no' => 'Plassering funnet'
][$current_lang];

$coords_only = [
    'ua' => 'Координати',
    'en' => 'Coordinates',
    'no' => 'Koordinater'
][$current_lang];

$location_error = [
    'ua' => 'Помилка визначення місця',
    'en' => 'Location detection error',
    'no' => 'Feil ved bestemmelse av plassering'
][$current_lang];

$geo_denied = [
    'ua' => 'Доступ до геолокації заборонено',
    'en' => 'Geolocation access denied',
    'no' => 'Geolokasjon tilgang nektet'
][$current_lang];

$geo_unavailable = [
    'ua' => 'Інформація про місце недоступна',
    'en' => 'Location information unavailable',
    'no' => 'Plasseringsinformasjon utilgjengelig'
][$current_lang];

$geo_timeout = [
    'ua' => 'Час очікування вичерпано',
    'en' => 'Timeout exceeded',
    'no' => 'Tidsavbrudd overskredet'
][$current_lang];

$geo_unknown = [
    'ua' => 'Невідома помилка',
    'en' => 'Unknown error',
    'no' => 'Ukjent feil'
][$current_lang];

$geo_not_supported = [
    'ua' => 'Геолокація не підтримується вашим браузером',
    'en' => 'Geolocation not supported by your browser',
    'no' => 'Geolokasjon støttes ikke av din nettleser'
][$current_lang];

$important_note = [
    'ua' => 'Важливо',
    'en' => 'Important',
    'no' => 'Viktig'
][$current_lang];

$publish_date_auto = [
    'ua' => 'Дата публікації встановлюється автоматично',
    'en' => 'Publication date is set automatically',
    'no' => 'Publiseringsdato settes automatisk'
][$current_lang];

$back_to_home = [
    'ua' => 'Повернутися на головну',
    'en' => 'Back to home',
    'no' => 'Tilbake til hovedside'
][$current_lang];

$submit_news = [
    'ua' => 'Надіслати новину на модерацію',
    'en' => 'Submit news for moderation',
    'no' => 'Send nyhet til moderering'
][$current_lang];

$event_date = [
    'ua' => 'Дата події',
    'en' => 'Event Date',
    'no' => 'Dato for arrangement'
][$current_lang];

$location_label = [
    'ua' => 'Місце / місто',
    'en' => 'Location / City',
    'no' => 'Sted / By'
][$current_lang];

$photo_label = [
    'ua' => 'Фото новини / події',
    'en' => 'News / Event Photo',
    'no' => 'Bilde til nyhet / arrangement'
][$current_lang];
?>

<!DOCTYPE html>
<html lang="<?= $current_lang ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title_page) ?> — <?= e($texts['site_title']) ?></title>

    <!-- Шрифти та стилі -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: #f8f9fc;
            padding: 2rem;
            max-width: 800px;
            margin: 0 auto;
            color: #333;
        }
        h1 {
            color: #0066cc;
            text-align: center;
            margin-bottom: 2rem;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #333;
        }
        input, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
        }
        textarea {
            min-height: 120px;
        }
        button {
            width: 100%;
            padding: 16px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
            margin: 0.5rem 0;
        }
        button:hover {
            background: #218838;
            transform: translateY(-2px);
        }
        .geo-btn {
            background: #4361ee;
            color: white;
        }
        .geo-btn:hover {
            background: #3a56d4;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 2rem;
            color: #0066cc;
            text-decoration: none;
            font-weight: 500;
        }
        .back-link:hover {
            text-decoration: underline;
        }
        #coordsResult {
            margin-top: 0.5rem;
            font-size: 0.95rem;
            color: #555;
        }
        @media (max-width: 768px) {
            body { padding: 1rem; }
            h1 { font-size: 1.8rem; }
        }
    </style>
</head>
<body>

<!-- Кнопки вибору мови зверху -->
<div class="lang-switch-top" style="text-align:center; padding:0.5rem 0; background:rgba(67,97,238,0.05); border-bottom:1px solid #eee; margin-bottom:1.5rem;">
    <?php foreach ($available_langs as $code => $lang): ?>
        <a href="?lang=<?= $code ?>" class="lang-flag <?= $current_lang === $code ? 'active' : '' ?>" title="<?= $lang['name'] ?>" style="font-size:2rem; margin:0 1rem; text-decoration:none; transition:transform 0.2s ease; cursor:pointer;">
            <?= $lang['flag'] ?>
        </a>
    <?php endforeach; ?>
</div>

<h1><?= htmlspecialchars($title_page) ?></h1>

<?php if (!empty($errors)): ?>
    <div class="error">
        <?php foreach ($errors as $err): ?>
            <p><?= htmlspecialchars($err) ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if (!empty($success)): ?>
    <div class="success">
        <?= htmlspecialchars($success) ?>
    </div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label for="title"><?= e($texts['title'] ?? 'Заголовок новини / події') ?> *</label>
        <input type="text" id="title" name="title" required value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
    </div>

    <div class="form-group">
        <label for="description"><?= e($texts['description'] ?? 'Опис новини / події') ?> *</label>
        <textarea id="description" name="description" required><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
    </div>

    <div class="form-group">
        <label for="date"><?= e($texts['event_date'] ?? 'Дата події') ?> (необов’язково)</label>
        <input type="date" id="date" name="date" value="<?= htmlspecialchars($_POST['date'] ?? '') ?>">
    </div>

    <div class="form-group">
        <label for="location"><?= e($texts['location'] ?? 'Місце / місто') ?></label>
        <input type="text" id="location" name="location" value="<?= htmlspecialchars($_POST['location'] ?? '') ?>" placeholder="<?= e($texts['location_placeholder'] ?? 'Наприклад: Oslo, Norway') ?>">
    </div>

    <div class="form-group">
        <button type="button" class="geo-btn" id="getLocationBtn">
            <i class="fas fa-map-marker-alt"></i> <?= e($texts['find_my_location'] ?? 'Визначити моє місце автоматично') ?>
        </button>
        <div id="coordsResult" style="margin-top: 0.8rem;"></div>
        <input type="hidden" name="lat" id="lat">
        <input type="hidden" name="lng" id="lng">
    </div>

    <div class="form-group">
        <label for="photo"><?= e($texts['photo'] ?? 'Фото новини / події') ?> (необов’язково)</label>
        <input type="file" id="photo" name="photo" accept="image/*">
    </div>

    <button type="submit"><?= e($texts['submit_news'] ?? 'Надіслати новину на модерацію') ?></button>
</form>

<p style="text-align:center; margin-top:1.5rem; color:#666;">
    <strong><?= e($texts['important_note'] ?? 'Важливо') ?>:</strong> <?= e($texts['publish_date_auto'] ?? 'Дата публікації встановлюється автоматично') ?>.
</p>

<a href="/" class="back-link">← <?= e($texts['back_to_home'] ?? 'Повернутися на головну') ?></a>

<script>
// Автоматичне визначення місця розташування
document.getElementById('getLocationBtn').addEventListener('click', function() {
    const resultDiv = document.getElementById('coordsResult');
    resultDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <?= e($texts['locating'] ?? 'Визначення місця...') ?>';

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                document.getElementById('lat').value = lat;
                document.getElementById('lng').value = lng;

                // Зворотний геокодинг (Nominatim)
                fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`)
                    .then(response => response.json())
                    .then(data => {
                        const city = data.address.city || data.address.town || data.address.village || '<?= e($texts['unknown_place'] ?? 'Невідоме місце') ?>';
                        document.getElementById('location').value = city;
                        resultDiv.innerHTML = `<span style="color:#28a745;"><?= e($texts['location_determined'] ?? 'Місце визначено') ?>: ${city} (${lat.toFixed(5)}, ${lng.toFixed(5)})</span>`;
                    })
                    .catch(() => {
                        resultDiv.innerHTML = `<span style="color:#28a745;"><?= e($texts['coords_only'] ?? 'Координати') ?>: ${lat.toFixed(5)}, ${lng.toFixed(5)}</span>`;
                    });
            },
            (error) => {
                let msg = '<?= e($texts['location_error'] ?? 'Помилка визначення місця') ?>: ';
                switch(error.code) {
                    case error.PERMISSION_DENIED: msg += '<?= e($texts['geo_denied'] ?? 'Доступ до геолокації заборонено') ?>'; break;
                    case error.POSITION_UNAVAILABLE: msg += '<?= e($texts['geo_unavailable'] ?? 'Інформація про місце недоступна') ?>'; break;
                    case error.TIMEOUT: msg += '<?= e($texts['geo_timeout'] ?? 'Час очікування вичерпано') ?>'; break;
                    default: msg += '<?= e($texts['geo_unknown'] ?? 'Невідома помилка') ?>';
                }
                resultDiv.innerHTML = `<span style="color:#e74c3c;">${msg}</span>`;
            },
            { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
        );
    } else {
        resultDiv.innerHTML = '<span style="color:#e74c3c;"><?= e($texts['geo_not_supported'] ?? 'Геолокація не підтримується вашим браузером') ?></span>';
    }
});
</script>
</body>
</html>