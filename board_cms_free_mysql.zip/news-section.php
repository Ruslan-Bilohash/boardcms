<?php
// news-section.php — Секція новин та подій на головній сторінці сайту
// Оновлено: 2 січня 2026 року
// ✅ Повна підтримка перекладів (ua/en/no) прямо в файлі
// ✅ Адаптивний дизайн для всіх пристроїв (clamp, grid auto-fit, media-запити)
// ✅ Lazy loading фото, hover-ефекти, плавні анімації
// ✅ Мотивуюча порожня секція

require_once $_SERVER['DOCUMENT_ROOT'] . '/config.php';

// Масив перекладів ТІЛЬКИ для цієї секції
$texts = [
    'ua' => [
        'news_events'     => 'Новини та події',
        'news_subtitle'   => 'Останні оновлення, події та важливі новини від MapsMe Norway',
        'no_news_title'   => 'Поки що немає опублікованих новин',
        'no_news_text'    => 'Будьте першим, хто додасть важливу подію чи новину про життя українців у Норвегії!',
        'add_first_news'  => 'Додати першу новину',
        'event'           => 'Подія',
        'read_more'       => 'Читати повністю',
        'view_all_news'   => 'Переглянути всі новини',
    ],
    'en' => [
        'news_events'     => 'News & Events',
        'news_subtitle'   => 'Latest updates, events and important news from MapsMe Norway',
        'no_news_title'   => 'No published news yet',
        'no_news_text'    => 'Be the first to add an important event or news about Ukrainians life in Norway!',
        'add_first_news'  => 'Add the first news',
        'event'           => 'Event',
        'read_more'       => 'Read more',
        'view_all_news'   => 'View all news',
    ],
    'no' => [
        'news_events'     => 'Nyheter og hendelser',
        'news_subtitle'   => 'Siste oppdateringer, hendelser og viktige nyheter fra MapsMe Norway',
        'no_news_title'   => 'Ingen publiserte nyheter ennå',
        'no_news_text'    => 'Vær den første til å legge til en viktig hendelse eller nyhet om ukrainernes liv i Norge!',
        'add_first_news'  => 'Legg til første nyhet',
        'event'           => 'Hendelse',
        'read_more'       => 'Les mer',
        'view_all_news'   => 'Se alle nyheter',
    ]
];

// Вибираємо переклади для поточної мови (fallback на українську)
$current_texts = $texts[$current_lang] ?? $texts['ua'];

// Визначаємо поля залежно від поточної мови
$title_field = "title_{$current_lang}";
$desc_field  = "description_{$current_lang}";

// Fallback на українську
$title_fallback = ($current_lang !== 'ua') ? 'title_ua' : $title_field;
$desc_fallback  = ($current_lang !== 'ua') ? 'description_ua' : $desc_field;

try {
    $stmt = $pdo->query("
        SELECT id,
               $title_field AS title,
               $desc_field AS description,
               $title_fallback AS title_fallback,
               $desc_fallback AS desc_fallback,
               photo, event_date, location, lat, lng, created_at
        FROM news
        WHERE status = 'published'
        ORDER BY created_at DESC
        LIMIT 12
    ");
    $news_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $news_items = [];
    error_log("Помилка завантаження новин: " . $e->getMessage());
}
?>

<section id="news-events" class="news-section">
    <div class="container">
        <!-- Заголовок секції -->
        <div class="section-header">
            <h2 class="section-title"><?= htmlspecialchars($current_texts['news_events']) ?></h2>
            <p class="section-subtitle"><?= htmlspecialchars($current_texts['news_subtitle']) ?></p>
        </div>

        <?php if (empty($news_items)): ?>
            <!-- Порожня секція — мотивуюча -->
            <div class="no-news-block">
                <div class="no-news-icon">
                    <i class="far fa-newspaper"></i>
                </div>
                <h3 class="no-news-title"><?= htmlspecialchars($current_texts['no_news_title']) ?></h3>
                <p class="no-news-text">
                    <?= htmlspecialchars($current_texts['no_news_text']) ?>
                </p>
                <a href="/admin/news_add.php" target="_blank" class="add-first-news-btn">
                    <i class="fas fa-plus-circle"></i>
                    <?= htmlspecialchars($current_texts['add_first_news']) ?>
                </a>
            </div>
        <?php else: ?>
            <!-- Сітка карток новин -->
            <div class="news-grid">
                <?php foreach ($news_items as $news): ?>
                    <?php
                    $title = !empty($news['title']) ? $news['title'] : ($news['title_fallback'] ?? 'Без назви');
                    $desc = !empty($news['description']) ? $news['description'] : ($news['desc_fallback'] ?? '');
                    $short_desc = mb_strlen(strip_tags($desc)) > 160
                        ? mb_substr(strip_tags($desc), 0, 160) . '...'
                        : strip_tags($desc);
                    ?>
                    <article class="news-card">
                        <?php if (!empty($news['photo'])): ?>
                            <div class="news-card-image">
                                <img src="<?= htmlspecialchars($news['photo']) ?>"
                                     alt="<?= htmlspecialchars($title) ?>"
                                     loading="lazy"
                                     decoding="async">
                            </div>
                        <?php endif; ?>

                        <div class="news-card-content">
                            <div class="news-card-meta">
                                <span class="news-date">
                                    <i class="far fa-calendar-alt"></i>
                                    <?= date('d.m.Y', strtotime($news['created_at'])) ?>
                                </span>
                                <?php if (!empty($news['event_date'])): ?>
                                    <span class="news-event-date">
                                        <i class="far fa-clock"></i>
                                        <?= htmlspecialchars($current_texts['event']) ?>: 
                                        <?= date('d.m.Y', strtotime($news['event_date'])) ?>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <h3 class="news-title"><?= htmlspecialchars($title) ?></h3>
                            <p class="news-excerpt"><?= htmlspecialchars($short_desc) ?></p>

                            <div class="news-footer">
                                <?php if (!empty($news['location'])): ?>
                                    <span class="news-location">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <?= htmlspecialchars($news['location']) ?>
                                    </span>
                                <?php endif; ?>

                                <a href="/news/<?= $news['id'] ?>" class="news-read-more">
                                    <?= htmlspecialchars($current_texts['read_more']) ?>
                                    <i class="fas fa-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>

            <!-- Кнопка "Всі новини" -->
            <div class="all-news-btn-wrapper">
                <a href="/news" class="all-news-btn">
                    <?= htmlspecialchars($current_texts['view_all_news']) ?>
                    <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        <?php endif; ?>
    </div>
</section>

<style>
/* Адаптивний та сучасний дизайн */
.news-section {
    padding: clamp(3rem, 8vw, 8rem) 0;
    background: linear-gradient(135deg, #f8faff 0%, #e0e7ff 50%, #c7d2fe 100%);
}

.container {
    max-width: 1280px;
    margin: 0 auto;
    padding: 0 clamp(1rem, 5vw, 5%);
}

.section-header {
    text-align: center;
    margin-bottom: clamp(3rem, 8vw, 5rem);
}

.section-title {
    font-family: 'Playfair Display', serif;
    font-size: clamp(2.4rem, 7vw, 4.5rem);
    color: #1e293b;
    margin: 0 0 1rem;
}

.section-subtitle {
    font-size: clamp(1rem, 3vw, 1.4rem);
    color: #4b5563;
    max-width: 720px;
    margin: 0 auto;
}

/* Порожня секція */
.no-news-block {
    text-align: center;
    padding: clamp(4rem, 10vw, 8rem) 2rem;
    background: white;
    border-radius: 32px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.1);
    max-width: 800px;
    margin: 0 auto;
}

.no-news-icon {
    font-size: clamp(5rem, 15vw, 8rem);
    color: #4361ee;
    opacity: 0.15;
    margin-bottom: 2rem;
}

.no-news-title {
    font-size: clamp(1.8rem, 5vw, 2.2rem);
    color: #1e293b;
    margin-bottom: 1rem;
}

.no-news-text {
    font-size: clamp(1rem, 3vw, 1.2rem);
    color: #6b7280;
    margin-bottom: 2.5rem;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
}

.add-first-news-btn {
    display: inline-flex;
    align-items: center;
    gap: 1rem;
    padding: clamp(1rem, 3vw, 1.3rem) clamp(2rem, 5vw, 3rem);
    background: linear-gradient(90deg, #4361ee, #3b82f6);
    color: white;
    border-radius: 50px;
    text-decoration: none;
    font-size: clamp(1.1rem, 3vw, 1.3rem);
    font-weight: 700;
    box-shadow: 0 10px 30px rgba(67,97,238,0.3);
    transition: all 0.4s ease;
}

.add-first-news-btn:hover {
    transform: translateY(-6px) scale(1.05);
    box-shadow: 0 20px 50px rgba(67,97,238,0.45);
}

/* Сітка карток */
.news-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(clamp(300px, 45vw, 380px), 1fr));
    gap: clamp(1.5rem, 4vw, 2.5rem);
}

.news-card {
    background: white;
    border-radius: 24px;
    overflow: hidden;
    box-shadow: 0 10px 35px rgba(0,0,0,0.08);
    transition: all 0.4s ease;
}

.news-card:hover {
    transform: translateY(-12px);
    box-shadow: 0 25px 60px rgba(67,97,238,0.15);
}

.news-card-image {
    height: clamp(180px, 40vw, 240px);
    overflow: hidden;
}

.news-card-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.6s ease;
}

.news-card:hover .news-card-image img {
    transform: scale(1.08);
}

.news-card-content {
    padding: clamp(1.5rem, 4vw, 2rem);
}

.news-card-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    margin-bottom: 1rem;
    font-size: clamp(0.85rem, 2vw, 0.95rem);
    color: #6b7280;
}

.news-title {
    font-size: clamp(1.4rem, 4vw, 1.6rem);
    margin: 0 0 1rem;
    line-height: 1.3;
    color: #1e293b;
    font-weight: 700;
}

.news-excerpt {
    color: #4b5563;
    line-height: 1.6;
    margin-bottom: 1.5rem;
    font-size: clamp(0.95rem, 2.5vw, 1.05rem);
}

.news-footer {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
}

.news-location {
    font-size: clamp(0.85rem, 2vw, 0.95rem);
    color: #4361ee;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.news-read-more {
    display: inline-flex;
    align-items: center;
    gap: 0.6rem;
    color: var(--primary);
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s;
}

.news-read-more:hover {
    color: #3b82f6;
    gap: 0.9rem;
}

/* Кнопка "Всі новини" */
.all-news-btn-wrapper {
    text-align: center;
    margin-top: clamp(4rem, 10vw, 5rem);
}

.all-news-btn {
    display: inline-flex;
    align-items: center;
    gap: 1rem;
    padding: clamp(1rem, 3vw, 1.2rem) clamp(2rem, 5vw, 3rem);
    background: var(--primary);
    color: white;
    border-radius: 50px;
    text-decoration: none;
    font-size: clamp(1.1rem, 3vw, 1.25rem);
    font-weight: 700;
    box-shadow: 0 10px 30px rgba(67,97,238,0.3);
    transition: all 0.4s;
}

.all-news-btn:hover {
    transform: translateY(-6px);
    box-shadow: 0 20px 50px rgba(67,97,238,0.45);
}

/* Адаптивність */
@media (max-width: 768px) {
    .news-grid { grid-template-columns: 1fr; }
    .section-header { margin-bottom: 3rem; }
    .no-news-block { padding: 6rem 1.5rem; }
}

@media (max-width: 480px) {
    .news-card-image { height: 180px; }
    .news-title { font-size: 1.4rem; }
    .news-excerpt { font-size: 0.95rem; }
}
</style>