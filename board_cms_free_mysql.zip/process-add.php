<?php
// process-add.php
header('Content-Type: application/json; charset=utf-8');

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['success' => false, 'error' => 'Method Not Allowed']));
}

$required = ['title', 'type', 'gdpr_consent'];
$data = [];
$errors = [];

foreach ($required as $field) {
    $data[$field] = trim($_POST[$field] ?? '');
    if ($data[$field] === '') {
        $errors[] = "Поле $field обов'язкове";
    }
}

if (!empty($errors)) {
    http_response_code(400);
    exit(json_encode(['success' => false, 'errors' => $errors]));
}

$data += [
    'description' => trim($_POST['description'] ?? ''),
    'city'        => trim($_POST['city'] ?? ''),
    'price'       => trim($_POST['price'] ?? ''),
    'contact'     => trim($_POST['contact'] ?? ''),
    'lat'         => floatval($_POST['lat'] ?? 0) ?: null,
    'lng'         => floatval($_POST['lng'] ?? 0) ?: null,
    'created_at'  => date('Y-m-d H:i:s'),
    'status'      => 'pending',
    'ip'          => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    'photo'       => null
];

// Фото
if (!empty($_FILES['photo']['name']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
    $upload_dir = 'uploads/ads/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

    $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif'];

    if (in_array($ext, $allowed)) {
        $filename = date('Ymd_His') . '_' . uniqid() . '.' . $ext;
        $target = $upload_dir . $filename;

        if (move_uploaded_file($_FILES['photo']['tmp_name'], $target)) {
            $data['photo'] = '/' . $target;
        }
    }
}

// Збереження в MySQL
try {
    $stmt = $pdo->prepare("
        INSERT INTO ads (title, type, description, city, price, contact, lat, lng, photo, created_at, status, ip)
        VALUES (:title, :type, :description, :city, :price, :contact, :lat, :lng, :photo, :created_at, :status, :ip)
    ");
    $stmt->execute($data);
} catch (PDOException $e) {
    http_response_code(500);
    exit(json_encode(['success' => false, 'error' => 'Помилка БД: ' . $e->getMessage()]));
}

echo json_encode([
    'success' => true,
    'message' => 'Оголошення додано! Після модерації з’явиться на сайті та карті.'
]);