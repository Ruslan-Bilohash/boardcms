<?php
// debug_system.php
// Однофайловый дебаггер + логгер + простая админка (только просмотр)
// Размещать в корне сайта или в защищённой папке

// ==============================================
// КОНФИГУРАЦИЯ
// ==============================================
define('DEBUG_ENABLED', true);              // глобальный выключатель отладки
define('ADMIN_PASSWORD', 'супер_секретный_пароль_2025'); // ← поменяй обязательно!
define('SESSION_LIFETIME_DAYS', 365 * 10);  // ~10 лет
define('ERROR_LOG_FILE', __DIR__ . '/error_admin.log');
define('GOOD_LOG_FILE',  __DIR__ . '/good_log.log');
define('ADMIN_SCRIPT_NAME', 'debug_system.php'); // имя этого файла

// Защита от записи в админке
define('ADMIN_READONLY', true);

// ==============================================
// СТАРТ СЕССИИ С ОЧЕНЬ ДОЛГИМ ЖИЗНЕННЫМ ЦИКЛОМ
// ==============================================
ini_set('session.gc_maxlifetime', 60 * 60 * 24 * SESSION_LIFETIME_DAYS);
session_set_cookie_params([
    'lifetime' => 60 * 60 * 24 * SESSION_LIFETIME_DAYS,
    'path'     => '/',
    'domain'   => '',
    'secure'   => isset($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax'
]);

session_name('DBGSESS');
session_start();

// ==============================================
// АВТОРИЗАЦИЯ АДМИНА
// ==============================================
$isAdmin = isset($_SESSION['is_debug_admin']) && $_SESSION['is_debug_admin'] === true;

if (isset($_GET['login'])) {
    if (isset($_POST['pass']) && $_POST['pass'] === ADMIN_PASSWORD) {
        $_SESSION['is_debug_admin'] = true;
        $_SESSION['login_time'] = time();
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $login_error = true;
    }
}

if (isset($_GET['logout'])) {
    $_SESSION = [];
    session_destroy();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ==============================================
// ФУНКЦИИ ЛОГИРОВАНИЯ
// ==============================================
function log_error($message, $file = '', $line = '', $context = '') {
    if (!DEBUG_ENABLED) return;
    
    $time = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $uri = $_SERVER['REQUEST_URI'] ?? '-';
    
    $log = "[$time] ERROR | IP: $ip | URI: $uri | File: $file | Line: $line\n";
    $log .= "Message: $message\n";
    if ($context) $log .= "Context: $context\n";
    $log .= str_repeat('-', 80) . "\n";
    
    @file_put_contents(ERROR_LOG_FILE, $log, FILE_APPEND | LOCK_EX);
}

function log_success($message) {
    if (!DEBUG_ENABLED) return;
    
    $time = date('Y-m-d H:i:s');
    $log = "[$time] GOOD | $message\n" . str_repeat('-', 60) . "\n";
    
    @file_put_contents(GOOD_LOG_FILE, $log, FILE_APPEND | LOCK_EX);
}

// ==============================================
// ГЛОБАЛЬНЫЙ ОБРАБОТЧИК ОШИБОК
// ==============================================
if (DEBUG_ENABLED) {
    set_error_handler(function($errno, $errstr, $errfile, $errline) {
        if (!(error_reporting() & $errno)) return false;
        
        $types = [
            E_ERROR => 'Error',
            E_WARNING => 'Warning',
            E_PARSE => 'Parse',
            E_NOTICE => 'Notice',
            E_CORE_ERROR => 'Core Error',
            E_CORE_WARNING => 'Core Warning',
            E_COMPILE_ERROR => 'Compile Error',
            E_COMPILE_WARNING => 'Compile Warning',
            E_USER_ERROR => 'User Error',
            E_USER_WARNING => 'User Warning',
            E_USER_NOTICE => 'User Notice',
            E_STRICT => 'Strict',
            E_RECOVERABLE_ERROR => 'Recoverable',
            E_DEPRECATED => 'Deprecated',
            E_USER_DEPRECATED => 'User Deprecated'
        ];
        
        $type = $types[$errno] ?? 'Unknown';
        log_error("$type: $errstr", $errfile, $errline);
        return false; // пусть стандартный обработчик тоже отработает
    });
    
    // Ловим фатальные ошибки (shutdown)
    register_shutdown_function(function() {
        $error = error_get_last();
        if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR])) {
            log_error("FATAL: {$error['message']}", $error['file'], $error['line']);
        }
    });
}

// ==============================================
// ПРОСТЕЙШАЯ АДМИНКА (ТОЛЬКО ПРОСМОТР)
// ==============================================
if ($isAdmin && !isset($_GET['raw'])) {
    header('Content-Type: text/html; charset=utf-8');
    ?>
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Debug Panel <?= date('Y-m-d H:i') ?></title>
        <style>
            body { font-family: Consolas, monospace; background:#111; color:#0f0; margin:0; padding:15px; line-height:1.4; }
            pre { background:#000; padding:15px; border-radius:6px; overflow:auto; max-height:80vh; }
            h1 { color:#0ff; margin-top:0; }
            .logs { display:flex; gap:20px; flex-wrap:wrap; }
            .log-block { flex:1; min-width:400px; }
            .log-block h2 { color:#f80; margin-bottom:8px; }
            .controls { margin:1em 0; }
            a { color:#0ff; }
            .logout { color:#f44; float:right; }
        </style>
    </head>
    <body>
        <h1>Debug Panel <small>(<?= php_uname('s') ?> | PHP <?= PHP_VERSION ?>)</small></h1>
        
        <div class="controls">
            <a href="?logout" class="logout">[ Выйти ]</a>
            <a href="?raw=error">[ Скачать error_admin.log ]</a> | 
            <a href="?raw=good">[ Скачать good_log.log ]</a> | 
            <a href="?clear=error" onclick="return confirm('Очистить error лог?')">Очистить ошибки</a> | 
            <a href="?clear=good" onclick="return confirm('Очистить good лог?')">Очистить успехи</a>
        </div>

        <div class="logs">
            <div class="log-block">
                <h2>Ошибки (error_admin.log)</h2>
                <pre><?php
                    $err_content = @file_get_contents(ERROR_LOG_FILE);
                    echo $err_content ? htmlspecialchars($err_content) : "→ Лог ошибок пуст или недоступен ←";
                ?></pre>
            </div>

            <div class="log-block">
                <h2>Успехи (good_log.log)</h2>
                <pre><?php
                    $good_content = @file_get_contents(GOOD_LOG_FILE);
                    echo $good_content ? htmlspecialchars($good_content) : "→ Лог успехов пуст ←";
                ?></pre>
            </div>
        </div>

        <p style="margin-top:2em; font-size:0.9em; color:#555;">
            Debug system v1.0 • Только чтение • Сессия бессрочная • <?= date('Y-m-d H:i:s') ?>
        </p>
    </body>
    </html>
    <?php
    exit;
}

// ==============================================
// РЕЖИМ СКАЧИВАНИЯ СЫРЫХ ЛОГОВ
// ==============================================
if ($isAdmin && isset($_GET['raw'])) {
    $file = $_GET['raw'] === 'good' ? GOOD_LOG_FILE : ERROR_LOG_FILE;
    $name = basename($file);
    
    if (file_exists($file)) {
        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        readfile($file);
        exit;
    } else {
        die("Файл $name не найден");
    }
}

// ==============================================
// ОЧИСТКА ЛОГОВ (только админ)
// ==============================================
if ($isAdmin && isset($_GET['clear'])) {
    $file = $_GET['clear'] === 'good' ? GOOD_LOG_FILE : ERROR_LOG_FILE;
    if (file_exists($file)) {
        file_put_contents($file, '');
        header("Location: " . ADMIN_SCRIPT_NAME);
        exit;
    }
}

// ==============================================
// ФОРМА ЛОГИНА (если не авторизован)
// ==============================================
if (!$isAdmin) {
    header('Content-Type: text/html; charset=utf-8');
    ?>
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>Debug Login</title>
        <style>
            body {font-family:Arial,sans-serif; background:#000; color:#0f0; display:flex; height:100vh; margin:0; align-items:center; justify-content:center;}
            .login-box {background:#111; padding:40px; border:1px solid #0f0; border-radius:8px; width:320px;}
            input {width:100%; padding:12px; margin:10px 0; background:#000; color:#0f0; border:1px solid #0a0; font-family:monospace;}
            button {width:100%; padding:12px; background:#0a0; color:#000; border:none; cursor:pointer; font-weight:bold;}
            .error {color:#f44; text-align:center; margin:10px 0;}
        </style>
    </head>
    <body>
        <div class="login-box">
            <h2 style="text-align:center; margin-top:0;">Debug Access</h2>
            <?php if (isset($login_error)): ?>
                <div class="error">Неверный пароль</div>
            <?php endif; ?>
            <form method="post" action="?login">
                <input type="password" name="pass" placeholder="Пароль..." autofocus required>
                <button type="submit">ВОЙТИ</button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Если сюда дошли — мы админ, можно использовать log_error() и log_success() в любом месте сайта

// Пример использования в коде сайта:
/*
log_error("Не удалось подключиться к базе", __FILE__, __LINE__, $db->error);
log_success("Пользователь {$user->id} успешно авторизовался");
*/