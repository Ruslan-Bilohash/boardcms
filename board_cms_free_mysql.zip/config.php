<?php
// config.php — Конфігурація сайту MapsMe Norway (з MySQL, 30.12.2025)
// Виправлено помилку з невизначеними константами DB_HOST тощо

// === Базові налаштування ===
define('SITE_NAME', 'MapsMe Norway');
define('SITE_URL',  'https://mapsme.no');

// === MySQL налаштування ===
define('DB_HOST', 'localhost');
define('DB_NAME', '');
define('DB_USER', '');
define('DB_PASS', '');

// Підключення до бази даних
$pdo = null;
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    // Якщо БД недоступна — не зупиняємо сайт, а просто логуємо помилку
    error_log("PDO Connection failed: " . $e->getMessage());
    // $pdo залишиться null — код, який використовує БД, може перевіряти це
}

// === Мови ===
$available_langs = [
    'ua' => ['name' => 'Українська', 'flag' => '🇺🇦'],
    'en' => ['name' => 'English',    'flag' => '🇬🇧'],
    'no' => ['name' => 'Norsk',      'flag' => '🇳🇴']
];

$current_lang = $_GET['lang'] ?? ($_COOKIE['lang'] ?? 'ua');

if (!array_key_exists($current_lang, $available_langs)) {
    $current_lang = 'ua';
}

setcookie('lang', $current_lang, time() + (86400 * 30), '/', '', false, true);

// Завантаження перекладів
$lang_file = __DIR__ . '/lang/' . $current_lang . '.php';
if (!file_exists($lang_file)) {
    $lang_file = __DIR__ . '/lang/ua.php';
}

$texts = include $lang_file;

// Функція екранування
function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}