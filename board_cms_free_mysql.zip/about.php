<?php
// about.php — Секція "Про нас" (мультимовна)
// Використовує змінні $current_lang та $lang з index.php
// НЕ містить жодних header/setcookie

$translations = [
    'ua' => [
        'title' => 'Про нас',
        'subtitle' => 'Зроблено українським розробником-ентузіастом',
        'author' => 'Руслан Білогаш',
        'free' => 'Розповсюджується повністю безкоштовно',
        'daily' => 'Кожен день — нові покращення, виправлення та функції. Відкритий код — беріть, змінюйте, поширюйте!',
        'open' => 'Відкритий код',
        'open_desc' => 'Повний доступ до коду. Змінюйте під себе.',
        'daily_updates' => 'Щоденні оновлення',
        'daily_desc' => 'Кожного дня — нові функції, виправлення, покращення.',
        'languages' => '3 мови',
        'lang_desc' => 'Українська · English · Norsk — повна локалізація.',
        'tech' => 'Технічні вимоги',
        'try' => 'Готові спробувати?',
        'try_desc' => 'Скрипт розповсюджується безкоштовно. Завантажуйте, встановлюйте, покращуйте — все у ваших руках!',
        'admin_alt' => 'Адмін-панель MapsMe Norway',
        'demo_title' => 'Демо адмін-панелі',
        'demo_desc' => 'Можете спробувати прямо зараз!',
        'demo_login' => 'Логін: <strong>admin</strong>',
        'demo_password' => 'Пароль: <strong>12345</strong>',
        'demo_button' => 'Відкрити демо-адмінку →',
        'demo_warning' => 'Це тестовий доступ. У реальному проекті використовуйте складний пароль!'
    ],
    'en' => [
        'title' => 'About Us',
        'subtitle' => 'Made by Ukrainian developer-enthusiast',
        'author' => 'Ruslan Bilogash',
        'free' => 'Distributed completely for free',
        'daily' => 'Every day — new improvements, fixes and features. Open source — take, modify, share!',
        'open' => 'Open Source',
        'open_desc' => 'Full code access. Customize it yourself.',
        'daily_updates' => 'Daily Updates',
        'daily_desc' => 'Every day — new features, fixes, improvements.',
        'languages' => '3 Languages',
        'lang_desc' => 'Ukrainian · English · Norsk — full localization.',
        'tech' => 'Technical Requirements',
        'try' => 'Ready to try?',
        'try_desc' => 'The script is distributed for free. Download, install, improve — it\'s all in your hands!',
        'admin_alt' => 'MapsMe Norway Admin Panel',
        'demo_title' => 'Admin Panel Demo',
        'demo_desc' => 'You can try it right now!',
        'demo_login' => 'Login: <strong>admin</strong>',
        'demo_password' => 'Password: <strong>12345</strong>',
        'demo_button' => 'Open demo admin panel →',
        'demo_warning' => 'This is a test access. Use a strong password in production!'
    ],
    'no' => [
        'title' => 'Om oss',
        'subtitle' => 'Laget av ukrainsk utvikler-entusiast',
        'author' => 'Ruslan Bilogash',
        'free' => 'Distribueres helt gratis',
        'daily' => 'Hver dag — nye forbedringer, rettelser og funksjoner. Åpen kildekode — ta, endre, del!',
        'open' => 'Åpen kildekode',
        'open_desc' => 'Full tilgang til koden. Tilpass den selv.',
        'daily_updates' => 'Daglig oppdateringer',
        'daily_desc' => 'Hver dag — nye funksjoner, rettelser, forbedringer.',
        'languages' => '3 språk',
        'lang_desc' => 'Ukrainsk · English · Norsk — full lokalisering.',
        'tech' => 'Tekniske krav',
        'try' => 'Klar til å prøve?',
        'try_desc' => 'Skriptet distribueres gratis. Last ned, installer, forbedre — alt er i dine hender!',
        'admin_alt' => 'MapsMe Norway Admin Panel',
        'demo_title' => 'Demo adminpanel',
        'demo_desc' => 'Du kan prøve det nå!',
        'demo_login' => 'Brukernavn: <strong>admin</strong>',
        'demo_password' => 'Passord: <strong>12345</strong>',
        'demo_button' => 'Åpne demo adminpanel →',
        'demo_warning' => 'Dette er testtilgang. Bruk sterkt passord i produksjon!'
    ]
];

$t = $translations[$current_lang] ?? $translations['ua'];
?>

<section id="about" style="padding: clamp(6rem, 10vw, 8rem) 0 clamp(4rem, 8vw, 6rem); background: linear-gradient(135deg, #f8faff 0%, #e0e7ff 50%, #c7d2fe 100%);">
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 5%;">

        <!-- ... (весь попередній контент залишається без змін: головний блок, переваги, тех. вимоги) ... -->

        <!-- Заклик до дії + ДЕМО АДМІНКИ -->
        <div style="text-align: center; margin-top: 6rem;">
            <h2 style="font-size: clamp(2.3rem, 6vw, 2.8rem); margin-bottom: 1.5rem;"><?= $t['try'] ?></h2>
            <p style="font-size: 1.4rem; color: #4b5563; max-width: 600px; margin: 0 auto 3rem;"><?= $t['try_desc'] ?></p>
            
            <img src="/admin_panel.jpg" 
                 alt="<?= $t['admin_alt'] ?>" 
                 loading="lazy" 
                 style="max-width:100%; border-radius:24px; box-shadow:0 25px 80px rgba(0,0,0,0.15); margin-bottom: 4rem;">

            <!-- БЛОК ДЕМО АДМІН-ПАНЕЛІ -->
            <div style="background: white; border-radius: 20px; padding: 2.5rem; max-width: 580px; margin: 0 auto; box-shadow: 0 15px 50px rgba(67,97,238,0.12);">
                <h3 style="font-size: 2rem; color: #4361ee; margin-bottom: 1rem;"><?= $t['demo_title'] ?></h3>
                <p style="font-size: 1.2rem; color: #4b5563; margin-bottom: 2rem;"><?= $t['demo_desc'] ?></p>
                
                <div style="display: flex; flex-wrap: wrap; gap: 1.5rem; justify-content: center; margin-bottom: 2rem; font-size: 1.15rem;">
                    <div style="background: #f0f4ff; padding: 1rem 1.8rem; border-radius: 12px;">
                        <?= $t['demo_login'] ?>
                    </div>
                    <div style="background: #f0f4ff; padding: 1rem 1.8rem; border-radius: 12px;">
                        <?= $t['demo_password'] ?>
                    </div>
                </div>

                <a href="/admin/login.php" 
                   target="_blank" 
                   style="display: inline-block; background: linear-gradient(90deg, #4361ee, #3b82f6); color: white; padding: 1.1rem 2.5rem; border-radius: 12px; text-decoration: none; font-size: 1.2rem; font-weight: 600; box-shadow: 0 8px 25px rgba(67,97,238,0.3); transition: all 0.3s;">
                    <?= $t['demo_button'] ?>
                </a>

                <p style="margin-top: 2rem; font-size: 0.95rem; color: #9ca3af;">
                    <?= $t['demo_warning'] ?>
                </p>
            </div>
        </div>

    </div>
</section>

<style>
    @keyframes pulse { 0%,100% { transform:scale(1); } 50% { transform:scale(1.08); } }
    a:hover { transform: translateY(-3px); box-shadow: 0 15px 40px rgba(67,97,238,0.4) !important; }
</style>