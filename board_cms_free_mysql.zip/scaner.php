<?php
// scanner.php
// Однофайловый сканер директорий и файлов с сохранением в log.json
// Запуск: http://ваш-сайт/scanner.php или из консоли: php scanner.php

// ================= НАСТРОЙКИ =================
$start_dir = __DIR__;              // Откуда начинать сканирование (текущая папка)
$max_depth = 8;                    // Максимальная глубина вложенности (защита от бесконечного обхода)
$log_file = __DIR__ . '/log.json'; // Куда сохранять результат
$exclude_dirs = [                  // Папки которые НЕ сканируем
    'vendor',
    'node_modules',
    '.git',
    'cache',
    '.idea',
    'logs',
    'temp',
    'tmp',
    'upload',
    'uploads',
    '__pycache__'
];
// ==============================================

header('Content-Type: text/plain; charset=utf-8');

if (php_sapi_name() === 'cli') {
    echo "Запуск в консоли...\n\n";
} else {
    if (!isset($_GET['run']) || $_GET['run'] !== 'true') {
        die("Для запуска в браузере добавьте ?run=true в конец адреса\n"
          . "Или запустите через консоль: php " . basename(__FILE__) . "\n");
    }
    echo "Сканирование начато...\n";
    flush();
}

$start_time = microtime(true);

$result = [
    'scan_started' => date('c'),
    'start_directory' => $start_dir,
    'php_version' => PHP_VERSION,
    'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'CLI',
    'structure' => []
];

function scan_dir_recursive($dir, $base_dir, $depth = 0, $max_depth, &$result, $exclude_dirs) {
    if ($depth > $max_depth) {
        return;
    }

    $dir = rtrim($dir, '/\\');
    $relative = ($dir === $base_dir) ? '' : substr($dir, strlen($base_dir) + 1);
    $key = $relative === '' ? 'root' : $relative;

    $current = [
        'path' => $relative,
        'absolute' => $dir,
        'files' => [],
        'subdirs' => [],
        'size' => 0,
        'count_files' => 0,
        'count_dirs' => 0
    ];

    try {
        $iterator = new DirectoryIterator($dir);
    } catch (Exception $e) {
        $current['error'] = $e->getMessage();
        $result['structure'][$key] = $current;
        return;
    }

    foreach ($iterator as $entry) {
        if ($entry->isDot()) {
            continue;
        }

        $name = $entry->getFilename();

        // Пропускаем исключённые папки
        if ($entry->isDir() && in_array($name, $exclude_dirs, true)) {
            continue;
        }

        $full_path = $entry->getPathname();

        if ($entry->isFile()) {
            $size = $entry->getSize();
            $current['files'][] = [
                'name' => $name,
                'size' => $size,
                'size_human' => format_size($size),
                'mtime' => date('Y-m-d H:i:s', $entry->getMTime()),
                'extension' => $entry->getExtension()
            ];
            $current['size'] += $size;
            $current['count_files']++;
        } elseif ($entry->isDir()) {
            $current['subdirs'][] = $name;
            $current['count_dirs']++;

            // Рекурсивный вызов
            scan_dir_recursive($full_path, $base_dir, $depth + 1, $max_depth, $result, $exclude_dirs);
        }
    }

    // Сортируем файлы по имени
    usort($current['files'], function($a, $b) {
        return strnatcasecmp($a['name'], $b['name']);
    });

    // Сортируем подпапки по имени
    sort($current['subdirs'], SORT_NATURAL | SORT_FLAG_CASE);

    $result['structure'][$key] = $current;
}

function format_size($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    }
    return $bytes . ' B';
}

// Запуск сканирования
scan_dir_recursive($start_dir, $start_dir, 0, $max_depth, $result, $exclude_dirs);

$result['scan_finished'] = date('c');
$result['duration_seconds'] = round(microtime(true) - $start_time, 3);
$result['total_dirs'] = count($result['structure']);

// Сохраняем в JSON
$json_options = JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
$json = json_encode($result, $json_options);

file_put_contents($log_file, $json);

echo "Сканирование завершено!\n";
echo "Время выполнения: " . $result['duration_seconds'] . " сек\n";
echo "Найдено папок: " . $result['total_dirs'] . "\n";
echo "Результат сохранён в: " . $log_file . "\n";
echo "Размер лога: " . format_size(filesize($log_file)) . "\n\n";

if (php_sapi_name() !== 'cli') {
    echo "Можно скачать лог: <a href='log.json' download>Скачать log.json</a>\n";
}