<?php
// captcha.php — Генератор простої CAPTCHA

session_start();

// Генерація випадкового коду (5 символів)
$code = substr(str_shuffle('23456789ABCDEFGHJKLMNPQRSTUVWXYZ'), 0, 5);
$_SESSION['captcha_code'] = $code;

// Створення зображення
$image = imagecreatetruecolor(150, 50);

// Кольори
$bg = imagecolorallocate($image, 255, 255, 255);
$text_color = imagecolorallocate($image, 30, 60, 150);
$noise_color = imagecolorallocate($image, 200, 200, 200);

// Фон
imagefill($image, 0, 0, $bg);

// Додавання шуму (крапки)
for ($i = 0; $i < 200; $i++) {
    imagesetpixel($image, rand(0, 149), rand(0, 49), $noise_color);
}

// Додавання ліній
for ($i = 0; $i < 5; $i++) {
    imageline($image, rand(0, 150), rand(0, 50), rand(0, 150), rand(0, 50), $noise_color);
}

// Текст CAPTCHA
$font = 'https://fonts.googleapis.com/css2?family=Roboto:wght@700'; // Якщо немає шрифту, використовуйте системний
imagettftext($image, 28, rand(-10, 10), 20, 40, $text_color, __DIR__ . '/arial.ttf', $code); // Замініть arial.ttf на ваш шрифт

// Виведення зображення
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);