<?php
// admin/news/index.php
session_start();
require_once '../../config.php'; // підключи свій конфіг з БД

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

$stmt = $pdo->query("SELECT id, title_ua, title_en, title_no, created_at, is_published 
                     FROM news 
                     ORDER BY created_at DESC");
$news = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактор новин · MapsMe Norway</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4361ee;
            --success: #10b981;
            --danger: #ef4444;
            --gray: #6b7280;
        }
        body {
            font-family: 'Manrope', sans-serif;
            background: #f8fafc;
            margin: 0;
            padding: 2rem;
        }
        .container { max-width: 1200px; margin: 0 auto; }
        h1 { margin-bottom: 2rem; }
        .btn { 
            display: inline-block;
            padding: 0.8rem 1.5rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: 0.2s;
        }
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: #3b51c9; transform: translateY(-1px); }
        .btn-danger { background: var(--danger); color: white; }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            border-radius: 12px;
            overflow: hidden;
        }
        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        th { background: #f1f5f9; color: var(--gray); }
        tr:hover { background: #f8fafc; }
        .status-published { color: var(--success); font-weight: 600; }
        .status-draft { color: var(--gray); }
        .actions a { margin-right: 1rem; color: var(--primary); }
    </style>
</head>
<body>

<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:2rem;">
        <h1>Редактор новин</h1>
        <a href="edit.php" class="btn btn-primary"><i class="fas fa-plus"></i> Додати новину</a>
    </div>

    <?php if (empty($news)): ?>
        <p style="text-align:center; color:#9ca3af; padding:4rem 0;">Поки що немає жодної новини</p>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Заголовок (UA)</th>
                <th>Дата</th>
                <th>Статус</th>
                <th>Дії</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($news as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item['title_ua'] ?: '—') ?></td>
                <td><?= date('d.m.Y H:i', strtotime($item['created_at'])) ?></td>
                <td>
                    <?php if ($item['is_published']): ?>
                        <span class="status-published">Опубліковано</span>
                    <?php else: ?>
                        <span class="status-draft">Чернетка</span>
                    <?php endif; ?>
                </td>
                <td class="actions">
                    <a href="edit.php?id=<?= $item['id'] ?>"><i class="fas fa-edit"></i> Редагувати</a>
                    <a href="delete.php?id=<?= $item['id'] ?>" 
                       onclick="return confirm('Ви дійсно хочете видалити цю новину?')" 
                       style="color:var(--danger);"><i class="fas fa-trash"></i> Видалити</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

</body>
</html>