<?php
// news-section.php — Блок новин та подій на головній сторінці
// Оновлено: 30 грудня 2025 року
// Мініатюра з фото, заголовком, коротким описом, посиланням та датою публікації
$news_items = getNews($pdo); // $pdo з config.php
?>

<div class="section" style="margin: 60px 0; padding: 0 1rem;">
    <h2 style="
        text-align: center;
        margin-bottom: 2.5rem;
        color: #4361ee;
        font-size: 2.2rem;
        font-weight: 700;
        font-family: 'Playfair Display', serif;
        position: relative;
    ">
        <?= e($texts['news_events']) ?>
        <span style="
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, #4361ee, #ff006e);
            margin: 0.8rem auto 0;
            border-radius: 2px;
        "></span>
    </h2>

    <?php if (empty($news_items)): ?>
        <p style="
            text-align: center;
            color: #666;
            font-size: 1.2rem;
            padding: 2rem;
            background: rgba(255,255,255,0.6);
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        ">
            <?= e($texts['no_news_yet']) ?>
        </p>
    <?php else: ?>
        <div class="grid" style="
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
            gap: 2rem;
        ">
            <?php foreach ($news_items as $item): ?>
                <div class="card" style="
                    background: white;
                    border-radius: 20px;
                    overflow: hidden;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                    transition: all 0.4s ease;
                    position: relative;
                ">
                    <!-- Фото (мініатюра) -->
                    <?php if (!empty($item['photo'])): ?>
                        <img src="<?= e($item['photo']) ?>" alt="<?= e($item['title']) ?>" style="
                            width: 100%;
                            height: 220px;
                            object-fit: cover;
                            border-bottom: 5px solid #4361ee;
                        " onerror="this.src='https://via.placeholder.com/340x220?text=Фото+відсутнє';">
                    <?php endif; ?>

                    <!-- Контент -->
                    <div class="card-body" style="padding: 1.8rem;">
                        <!-- Заголовок -->
                        <h3 style="
                            margin: 0 0 0.8rem;
                            font-size: 1.45rem;
                            color: #2b2d42;
                            font-weight: 700;
                            line-height: 1.3;
                        ">
                            <?= e($item['title']) ?>
                        </h3>

                        <!-- Короткий опис (3 рядки з обрізанням) -->
                        <p style="
                            margin: 0 0 1.2rem;
                            color: #555;
                            font-size: 1rem;
                            line-height: 1.6;
                            max-height: 4.8em;
                            overflow: hidden;
                            text-overflow: ellipsis;
                            display: -webkit-box;
                            -webkit-line-clamp: 3;
                            -webkit-box-orient: vertical;
                        ">
                            <?= nl2br(e($item['description'])) ?>
                        </p>

                        <!-- Інфо -->
                        <div style="display: flex; flex-wrap: wrap; gap: 1rem; color: #666; font-size: 0.95rem; margin-bottom: 1rem;">
                            <?php if (!empty($item['date'])): ?>
                                <div>
                                    <strong>Дата:</strong> <?= e($item['date']) ?>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($item['location'])): ?>
                                <div>
                                    <strong>Місце:</strong> <?= e($item['location']) ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Дата публікації + посилання -->
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <small style="color: #888; font-size: 0.9rem;">
                                Опубліковано: <?= date('d.m.Y H:i', strtotime($item['created_at'])) ?>
                            </small>

                            <a href="/news.php?id=<?= e($item['id']) ?>" style="
                                padding: 0.6rem 1.2rem;
                                background: #4361ee;
                                color: white;
                                border-radius: 50px;
                                text-decoration: none;
                                font-size: 0.9rem;
                                font-weight: 600;
                                transition: all 0.3s;
                            " onmouseover="this.style.background='#3a56d4'; this.style.transform='translateY(-2px)'" onmouseout="this.style.background='#4361ee'; this.style.transform='translateY(0)'">
                                Переглянути →
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Додаткові стилі (можна винести в main.css) -->
