<?php
// /admin/login.php — Простой вход для администратора
// Логин: admin
// Пароль: 12345
// Обновлено: 31 декабря 2025

session_start();

// Если уже вошли — сразу на главную админки
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: /admin/index.php");
    exit;
}

$error = '';

// Секретные данные (в реальном проекте храните в .env или config)
$admin_login    = 'admin';
$admin_password = '12345';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input_login    = trim($_POST['login'] ?? '');
    $input_password = $_POST['password'] ?? '';

    if (empty($input_login) || empty($input_password)) {
        $error = 'Заполните логин и пароль';
    } elseif ($input_login === $admin_login && $input_password === $admin_password) {
        // Успешный вход
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_name']      = 'Администратор';

        // Можно добавить время входа
        $_SESSION['admin_login_time'] = time();

        header("Location: /admin/index.php");
        exit;
    } else {
        $error = 'Неверный логин или пароль';
    }
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вхід в адмінку — MapsMe Norway</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: white;
            font-family: 'Manrope', sans-serif;
            min-height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            background: rgba(30, 41, 59, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 16px;
            padding: 3rem 2.5rem;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            border: 1px solid rgba(96, 165, 250, 0.2);
        }
        .logo {
            text-align: center;
            font-size: 3.5rem;
            margin-bottom: 1.5rem;
            color: #60a5fa;
        }
        h1 {
            text-align: center;
            margin: 0 0 2rem;
            font-size: 1.8rem;
            font-weight: 600;
        }
        .error {
            background: #dc2626;
            color: white;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .form-group {
            margin-bottom: 1.6rem;
            position: relative;
        }
        input {
            width: 100%;
            padding: 1rem 1rem 1rem 3.5rem;
            border: none;
            border-radius: 10px;
            background: #334155;
            color: white;
            font-size: 1rem;
        }
        input:focus {
            outline: none;
            box-shadow: 0 0 0 3px #60a5fa;
        }
        .input-icon {
            position: absolute;
            left: 1.2rem;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
        }
        button {
            width: 100%;
            padding: 1.1rem;
            background: linear-gradient(90deg, #3b82f6, #60a5fa);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(59, 130, 246, 0.4);
        }
    </style>
</head>
<body>

<div class="login-container">
    <div class="logo"><i class="fas fa-shield-halved"></i></div>
    <h1>Вхід в адмін-панель</h1>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <i class="fas fa-user input-icon"></i>
            <input type="text" name="login" placeholder="Логін" required autofocus>
        </div>

        <div class="form-group">
            <i class="fas fa-lock input-icon"></i>
            <input type="password" name="password" placeholder="Пароль" required>
        </div>

        <button type="submit">Увійти</button>
    </form>
</div>

</body>
</html>