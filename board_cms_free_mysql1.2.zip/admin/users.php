<?php
session_start();

// Тільки адмінська перевірка
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: /admin/login.php");
    exit;
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/config.php';
$page_title = 'Користувачі';
require_once $_SERVER['DOCUMENT_ROOT'] . '/admin/header.php';

$stmt = $pdo->query("SELECT id, name, login, role, status, created_at FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll();
?>

<h1>Список користувачів</h1>

<table style="width:100%; border-collapse:collapse; background:white; border-radius:12px; overflow:hidden; box-shadow:0 4px 15px rgba(0,0,0,0.1);">
    <thead style="background:#1e293b; color:white;">
        <tr>
            <th style="padding:1rem;">ID</th>
            <th style="padding:1rem;">Ім’я</th>
            <th style="padding:1rem;">Логін</th>
            <th style="padding:1rem;">Роль</th>
            <th style="padding:1rem;">Статус</th>
            <th style="padding:1rem;">Дата</th>
            <th style="padding:1rem;">Дії</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $u): ?>
        <tr style="border-bottom:1px solid #e2e8f0;">
            <td style="padding:1rem; text-align:center;"><?= $u['id'] ?></td>
            <td style="padding:1rem;"><?= htmlspecialchars($u['name']) ?></td>
            <td style="padding:1rem;"><?= htmlspecialchars($u['login']) ?></td>
            <td style="padding:1rem;"><?= htmlspecialchars($u['role']) ?></td>
            <td style="padding:1rem;"><?= htmlspecialchars($u['status']) ?></td>
            <td style="padding:1rem;"><?= date('d.m.Y H:i', strtotime($u['created_at'])) ?></td>
            <td style="padding:1rem; text-align:center;">
                <a href="/admin/user_edit.php?id=<?= $u['id'] ?>" style="color:#3b82f6; text-decoration:none;"><i class="fas fa-edit"></i></a>
                <a href="?delete=<?= $u['id'] ?>" onclick="return confirm('Видалити користувача?')" style="color:#ef4444; margin-left:1rem; text-decoration:none;"><i class="fas fa-trash"></i></a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/admin/footer.php'; ?>