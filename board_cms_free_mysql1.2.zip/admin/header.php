<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title ?? 'Адмін-панель') ?> — MapsMe Norway</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { margin:0; font-family:'Manrope',sans-serif; background:#f1f5f9; }
        header { background:#1e293b; color:white; padding:1rem 5%; display:flex; justify-content:space-between; align-items:center; position:sticky; top:0; z-index:1000; box-shadow:0 2px 10px rgba(0,0,0,0.3); }
        .logo { font-size:1.6rem; font-weight:700; }
        nav a { color:#cbd5e1; margin-left:1.8rem; text-decoration:none; font-weight:500; transition:0.2s; }
        nav a:hover { color:#60a5fa; }
        .container { max-width:1400px; margin:2rem auto; padding:0 5%; }
    </style>
</head>
<body>

<header>
    <div class="logo"><i class="fas fa-shield-halved"></i> MapsMe Admin</div>
    <nav>
        <a href="/admin/index.php">Головна</a>
        <a href="/admin/users.php">Користувачі</a>
        <a href="/admin/ads.php">Оголошення</a>
        <a href="/admin/news.php">Новини</a>
        <a href="/admin/logout.php">Вийти</a>
    </nav>
</header>

<div class="container">