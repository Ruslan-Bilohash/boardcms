<?php
session_start();

// Тільки адмінська перевірка
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: /admin/login.php");
    exit;
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/config.php';
$page_title = 'Новини';
require_once $_SERVER['DOCUMENT_ROOT'] . '/admin/header.php';

$stmt = $pdo->query("SELECT id, title_ua, status, created_at FROM news ORDER BY created_at DESC");
$news = $stmt->fetchAll();
?>

<h1>Список новин</h1>

<table style="width:100%; border-collapse:collapse; background:white; border-radius:12px; overflow:hidden; box-shadow:0 4px 15px rgba(0,0,0,0.1);">
    <thead style="background:#1e293b; color:white;">
        <tr>
            <th style="padding:1rem;">ID</th>
            <th style="padding:1rem;">Заголовок (укр)</th>
            <th style="padding:1rem;">Статус</th>
            <th style="padding:1rem;">Дата</th>
            <th style="padding:1rem;">Дії</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($news as $n): ?>
        <tr style="border-bottom:1px solid #e2e8f0;">
            <td style="padding:1rem; text-align:center;"><?= $n['id'] ?></td>
            <td style="padding:1rem;"><?= htmlspecialchars($n['title_ua']) ?></td>
            <td style="padding:1rem;"><?= htmlspecialchars($n['status']) ?></td>
            <td style="padding:1rem;"><?= date('d.m.Y H:i', strtotime($n['created_at'])) ?></td>
            <td style="padding:1rem; text-align:center;">
                <a href="/admin/news_edit.php?id=<?= $n['id'] ?>" style="color:#3b82f6;"><i class="fas fa-edit"></i></a>
                <a href="?delete_news=<?= $n['id'] ?>" onclick="return confirm('Видалити новину?')" style="color:#ef4444; margin-left:1rem;"><i class="fas fa-trash"></i></a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/admin/footer.php'; ?>