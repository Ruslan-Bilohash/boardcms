</div>

<footer style="background:#1e293b; color:#cbd5e1; text-align:center; padding:2rem; margin-top:4rem;">
    <p>© <?= date('Y') ?> MapsMe Norway Admin Panel</p>
    <p style="margin-top:0.5rem; opacity:0.7;">Розроблено для допомоги українській спільноті в Норвегії</p>
</footer>

</body>
</html>