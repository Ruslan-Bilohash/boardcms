<?php
// /admin/index.php — Главная админ-панель
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: /admin/login.php");
    exit;
}

// Можно добавить выход
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: /admin/login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Адмін-панель — MapsMe Norway</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { margin:0; font-family:'Manrope',sans-serif; background:#f1f5f9; color:#1e293b; }
        header { background:#1e293b; color:white; padding:1.2rem 5%; display:flex; justify-content:space-between; align-items:center; box-shadow:0 2px 10px rgba(0,0,0,0.3); position:sticky; top:0; z-index:1000; }
        .logo { font-size:1.7rem; font-weight:700; }
        .nav a { color:#cbd5e1; margin-left:1.8rem; text-decoration:none; font-weight:500; transition:0.2s; }
        .nav a:hover { color:#60a5fa; }
        .container { max-width:1200px; margin:3rem auto; padding:0 5%; }
        .welcome { text-align:center; margin-bottom:3rem; }
        .welcome h1 { font-size:2.5rem; margin:0.5rem 0; }
        .cards { display:grid; grid-template-columns:repeat(auto-fit, minmax(280px,1fr)); gap:1.8rem; }
        .card { background:white; border-radius:16px; padding:2rem; text-align:center; box-shadow:0 6px 20px rgba(0,0,0,0.1); transition:transform 0.3s; }
        .card:hover { transform:translateY(-8px); }
        .card i { font-size:3.5rem; color:#3b82f6; margin-bottom:1rem; }
        .card h3 { margin:0.8rem 0; font-size:1.4rem; }
        .card p { font-size:2.2rem; font-weight:700; margin:0; color:#1e293b; }
    </style>
</head>
<body>

<header>
    <div class="logo"><i class="fas fa-shield-halved"></i> Адмін-панель</div>
    <div class="nav">
        <a href="/admin/index.php">Головна</a>
        <a href="/admin/logout.php">Вийти</a>
    </div>
</header>

<div class="container">
    <div class="welcome">
        <h1>Ласкаво просимо, Адміністратор!</h1>
        <p>Вітаємо в адмін-панелі MapsMe Norway</p>
    </div>

    <div class="cards">
        <div class="card">
            <i class="fas fa-users"></i>
            <h3>Користувачі</h3>
            <p>Переглянути всіх</p>
        </div>

        <div class="card">
            <i class="fas fa-bullhorn"></i>
            <h3>Оголошення</h3>
            <p>Модерація та редагування</p>
        </div>

        <div class="card">
            <i class="fas fa-newspaper"></i>
            <h3>Новини</h3>
            <p>Додавання та публікація</p>
        </div>
    </div>
</div>

</body>
</html>