<div class="section">
    <h2><?= e($texts['news_events']) ?></h2>
    
    <?php
    $stmt = $pdo->prepare("SELECT * FROM news ORDER BY created_at DESC LIMIT 6");
    $stmt->execute();
    $news = $stmt->fetchAll();
    
    if (empty($news)):
    ?>
        <p style="text-align:center; color:#666;"><?= e($texts['no_news_yet']) ?></p>
    <?php else: ?>
        <div class="grid">
            <?php foreach ($news as $item): ?>
                <div class="card">
                    <div class="card-body">
                        <div class="card-title"><?= e($item['title']) ?></div>
                        <p><?= nl2br(e($item['description'])) ?></p>
                        <?php if ($item['date']): ?>
                            <div><strong>Дата:</strong> <?= e($item['date']) ?></div>
                        <?php endif; ?>
                        <?php if ($item['location']): ?>
                            <div><strong>Місце:</strong> <?= e($item['location']) ?></div>
                        <?php endif; ?>
                        <small style="color:#888;"><?= date('d.m.Y H:i', strtotime($item['created_at'])) ?></small>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>