<?php
// register.php — Реєстрація через MySQL (оновлено 31.12.2025)
// Вимоги: пароль від 5 символів, форма телефону як раніше, редирект на profile.php після успіху

session_start();

// Якщо вже авторизований — перенаправляємо в профіль
if (isset($_SESSION['user_id'])) {
    header("Location: /profile.php");
    exit;
}

// Підключаємо конфігурацію (звідси беремо $pdo)
require_once $_SERVER['DOCUMENT_ROOT'] . '/config.php';

if (!$pdo) {
    die("Помилка: Не вдалося підключитися до бази даних. Перевірте config.php");
}

// Підтримка мов (синхронізовано з config.php)
$current_lang = $_SESSION['lang'] ?? ($_COOKIE['lang'] ?? 'ua');
if (isset($_GET['lang']) && array_key_exists($_GET['lang'], $available_langs)) {
    $current_lang = $_GET['lang'];
    $_SESSION['lang'] = $current_lang;
    setcookie('lang', $current_lang, time() + (86400 * 30), '/', '', false, true);
}

$t = $texts;

// Обробка форми реєстрації
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $login    = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if (empty($name)) {
        $error = $t['error_empty_name'] ?? 'Вкажіть ім’я';
    } elseif (empty($login)) {
        $error = $t['error_empty_login'] ?? 'Вкажіть email або телефон';
    } elseif (
        !filter_var($login, FILTER_VALIDATE_EMAIL) &&
        !preg_match('/^\+[0-9]{8,15}$/', $login)
    ) {
        $error = $t['error_invalid_login'] ?? 'Некоректний email або номер телефону (формат +код_країниxxxxxxxx)';
    } elseif (strlen($password) < 5) {
        $error = 'Пароль мінімум 5 символів';
    } elseif ($password !== $confirm) {
        $error = $t['error_pass_mismatch'] ?? 'Паролі не співпадають';
    } else {
        try {
            // Перевіряємо чи існує такий login
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE login = ?");
            $stmt->execute([$login]);
            if ($stmt->fetchColumn() > 0) {
                $error = $t['error_user_exists'] ?? 'Такий email або телефон вже зареєстрований';
            } else {
                $password_hash = password_hash($password, PASSWORD_DEFAULT);

                // Гнучкий INSERT — враховуємо, чи є стовпець status
                $columns = ['name', 'login', 'password', 'role', 'lang', 'created_at'];
                $values  = [$name, $login, $password_hash, 'user', $current_lang];
                $placeholders = '(?, ?, ?, ?, ?, NOW())';

                $check_status = $pdo->query("SHOW COLUMNS FROM users LIKE 'status'")->fetch();
                if ($check_status) {
                    $columns[] = 'status';
                    $values[] = 'active';
                    $placeholders = '(?, ?, ?, ?, ?, ?, NOW())';
                }

                $sql = "INSERT INTO users (" . implode(', ', $columns) . ") VALUES $placeholders";
                $stmt = $pdo->prepare($sql);
                $stmt->execute($values);

                // Записуємо ID користувача в сесію
                $user_id = $pdo->lastInsertId();
                $_SESSION['user_id'] = $user_id;

                // Автоматичний редирект на профіль
                header("Location: /profile.php");
                exit;
            }
        } catch (PDOException $e) {
            error_log("Registration error: " . $e->getMessage());
            $error = 'Помилка бази даних: ' . htmlspecialchars($e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="<?= htmlspecialchars($current_lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($t['title'] ?? 'Реєстрація — MapsMe Norway') ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/main.css?v=<?= time() ?>">
    <style>
        body {
            background: linear-gradient(135deg, #f0f4ff, #e6f0ff);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Manrope', sans-serif;
        }
        .register-box {
            background: white;
            border-radius: 24px;
            box-shadow: 0 20px 50px rgba(67,97,238,0.18);
            padding: 3rem 2.5rem;
            width: 100%;
            max-width: 480px;
            margin: 1rem;
        }
        .register-logo {
            width: 90px;
            height: 90px;
            background: linear-gradient(135deg, #4361ee, #7b2cbf);
            border-radius: 50%;
            display: grid;
            place-items: center;
            color: white;
            font-size: 2.8rem;
            margin: 0 auto 1.2rem;
            box-shadow: 0 10px 30px rgba(67,97,238,0.35);
        }
        .register-title {
            font-family: 'Playfair Display', serif;
            font-size: 2.4rem;
            color: #2b2d42;
            text-align: center;
            margin: 0 0 0.5rem;
        }
        .error-msg, .success-msg {
            padding: 0.9rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .error-msg   { background: #ffebee; color: #c62828; }
        .success-msg { background: #d4edda; color: #155724; }
        .form-group {
            margin-bottom: 1.6rem;
            position: relative;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.4rem;
            font-weight: 500;
            color: #555;
        }
        .form-group input {
            width: 100%;
            padding: 1.1rem 1.2rem 1.1rem 3.5rem;
            border: 1px solid #ddd;
            border-radius: 12px;
            font-size: 1rem;
            transition: border-color 0.2s;
        }
        .form-group input:focus {
            border-color: #4361ee;
            outline: none;
        }
        .form-group i {
            position: absolute;
            left: 1.2rem;
            top: 50%;
            transform: translateY(-50%);
            color: #8d99ae;
        }
        .btn-register {
            width: 100%;
            padding: 1.2rem;
            background: linear-gradient(135deg, #4361ee, #7b2cbf);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1.15rem;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .btn-register:hover {
            transform: translateY(-2px);
        }
        .lang-switcher {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .lang-switcher a {
            margin: 0 0.8rem;
            color: #555;
            text-decoration: none;
            font-weight: 500;
            padding: 4px 8px;
            border-radius: 6px;
        }
        .lang-switcher a.active {
            background: #4361ee;
            color: white;
        }
    </style>
</head>
<body>

<div class="register-box">
    <!-- Перемикач мов -->
    <div class="lang-switcher">
        <?php foreach ($available_langs as $code => $info): ?>
            <a href="?lang=<?= htmlspecialchars($code) ?>" class="<?= $current_lang === $code ? 'active' : '' ?>">
                <?= htmlspecialchars($info['name']) ?> <?= $info['flag'] ?>
            </a>
        <?php endforeach; ?>
    </div>

    <div class="register-header">
        <div class="register-logo"><i class="fas fa-house-user"></i></div>
        <h1 class="register-title"><?= htmlspecialchars($t['header'] ?? 'Реєстрація') ?></h1>
    </div>

    <?php if ($error): ?>
        <div class="error-msg"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success-msg"><?= $success ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="off">
        <div class="form-group">
            <label for="name"><?= htmlspecialchars($t['name_label'] ?? 'Ім’я') ?></label>
            <i class="fas fa-user"></i>
            <input type="text" id="name" name="name" required
                   value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label for="login"><?= htmlspecialchars($t['login_label'] ?? 'Email або телефон') ?></label>
            <i class="fas fa-envelope"></i>
            <input type="text" id="login" name="login" required
                   placeholder="example@email.com або +4712345678"
                   value="<?= htmlspecialchars($_POST['login'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label for="password"><?= htmlspecialchars($t['password_label'] ?? 'Пароль') ?></label>
            <i class="fas fa-lock"></i>
            <input type="password" id="password" name="password" required>
        </div>

        <div class="form-group">
            <label for="confirm"><?= htmlspecialchars($t['confirm_label'] ?? 'Підтвердіть пароль') ?></label>
            <i class="fas fa-lock"></i>
            <input type="password" id="confirm" name="confirm" required>
        </div>

        <button type="submit" class="btn-register"><?= htmlspecialchars($t['register_btn'] ?? 'Зареєструватися') ?></button>
    </form>

    <div style="text-align:center; margin-top:1.8rem; color:#8d99ae;">
        <?= htmlspecialchars($t['already_have'] ?? 'Вже є акаунт?') ?> 
        <a href="/login.php" style="color:#4361ee; font-weight:600;">
            <?= htmlspecialchars($t['login_link'] ?? 'Увійти') ?>
        </a>
    </div>
</div>

</body>
</html>