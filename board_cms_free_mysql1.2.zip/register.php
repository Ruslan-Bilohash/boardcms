<?php
// register.php — Реєстрація користувача через MySQL
// Оновлено: 31 грудня 2025 року
// Особливості:
// - Реєстрація по email АБО по номеру телефону
// - Пароль від 5 символів
// - Перемикач мов (ua/en/no)
// - Автоматичний редирект на /profile.php після успіху
// - Захист від SQL-ін'єкцій (PDO + prepared statements)
// - Красивий адаптивний дизайн

session_start();

// Якщо вже залогінений — одразу в профіль
if (isset($_SESSION['user_id'])) {
    header("Location: /profile.php");
    exit;
}

// Підключаємо конфігурацію (там має бути $pdo та $texts)
require_once $_SERVER['DOCUMENT_ROOT'] . '/config.php';

if (!$pdo) {
    die("Помилка: Не вдалося підключитися до бази даних. Перевірте config.php");
}

// Поточна мова (з сесії, кукі або за замовчуванням)
$current_lang = $_SESSION['lang'] ?? ($_COOKIE['lang'] ?? 'ua');

// Якщо користувач змінив мову через GET
if (isset($_GET['lang']) && array_key_exists($_GET['lang'], $available_langs)) {
    $current_lang = $_GET['lang'];
    $_SESSION['lang'] = $current_lang;
    setcookie('lang', $current_lang, time() + (86400 * 30), '/', '', false, true);
}

// $texts уже завантажено в config.php
$t = $texts;

// Список країн для телефону (можна розширити)
$phone_prefixes = [
    '+47'  => 'Норвегія',
    '+380' => 'Україна',
    '+370' => 'Литва',
    '+1'   => 'США/Канада',
    '+48'  => 'Польща',
    '+49'  => 'Німеччина'
];

// Обробка форми
$error = '';
$success = '';
$form_data = $_POST; // для заповнення полів при помилці

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $login    = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    // Валідація
    if (empty($name)) {
        $error = $t['error_empty_name'] ?? 'Вкажіть ім’я';
    } elseif (empty($login)) {
        $error = $t['error_empty_login'] ?? 'Вкажіть email або телефон';
    } elseif (
        !filter_var($login, FILTER_VALIDATE_EMAIL) &&
        !preg_match('/^\+[0-9]{8,15}$/', $login)
    ) {
        $error = $t['error_invalid_login'] ?? 'Некоректний email або номер телефону (+кодxxxxxxxx)';
    } elseif (strlen($password) < 5) {
        $error = 'Пароль мінімум 5 символів';
    } elseif ($password !== $confirm) {
        $error = $t['error_pass_mismatch'] ?? 'Паролі не співпадають';
    } else {
        try {
            // Перевірка на дублювання
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE login = ?");
            $stmt->execute([$login]);
            if ($stmt->fetchColumn() > 0) {
                $error = $t['error_user_exists'] ?? 'Такий email або телефон вже зареєстрований';
            } else {
                $password_hash = password_hash($password, PASSWORD_DEFAULT);

                // Гнучкий INSERT — перевіряємо наявність status
                $columns = ['name', 'login', 'password', 'role', 'lang', 'created_at'];
                $values  = [$name, $login, $password_hash, 'user', $current_lang];
                $placeholders = '(?, ?, ?, ?, ?, NOW())';

                $has_status = $pdo->query("SHOW COLUMNS FROM users LIKE 'status'")->fetch();
                if ($has_status) {
                    $columns[] = 'status';
                    $values[] = 'active';
                    $placeholders = '(?, ?, ?, ?, ?, ?, NOW())';
                }

                $sql = "INSERT INTO users (" . implode(', ', $columns) . ") VALUES $placeholders";
                $stmt = $pdo->prepare($sql);
                $stmt->execute($values);

                // Авторизуємо користувача
                $user_id = $pdo->lastInsertId();
                $_SESSION['user_id'] = $user_id;

                // Редирект у профіль
                header("Location: /profile.php");
                exit;
            }
        } catch (PDOException $e) {
            error_log("Помилка реєстрації: " . $e->getMessage());
            $error = 'Помилка бази даних: ' . htmlspecialchars($e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="<?= htmlspecialchars($current_lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($t['site_title'] ?? 'Реєстрація — MapsMe Norway') ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/main.css?v=<?= time() ?>">
    <style>
        body {
            background: linear-gradient(135deg, #f0f4ff, #e6f0ff);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Manrope', sans-serif;
            margin: 0;
        }
        .register-box {
            background: white;
            border-radius: 24px;
            box-shadow: 0 20px 50px rgba(67,97,238,0.18);
            padding: 3rem 2.5rem;
            width: 100%;
            max-width: 480px;
            margin: 1rem;
        }
        .logo-circle {
            width: 90px;
            height: 90px;
            background: linear-gradient(135deg, #4361ee, #7b2cbf);
            border-radius: 50%;
            display: grid;
            place-items: center;
            color: white;
            font-size: 2.8rem;
            margin: 0 auto 1.2rem;
            box-shadow: 0 10px 30px rgba(67,97,238,0.35);
        }
        .title {
            font-family: 'Playfair Display', serif;
            font-size: 2.4rem;
            color: #2b2d42;
            text-align: center;
            margin: 0 0 1.5rem;
        }
        .error, .success {
            padding: 1rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .error { background: #ffebee; color: #c62828; }
        .success { background: #e6ffe6; color: #006400; }
        .form-group {
            position: relative;
            margin-bottom: 1.6rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #555;
        }
        .form-group input {
            width: 100%;
            padding: 1.1rem 1.2rem 1.1rem 3.5rem;
            border: 1px solid #ddd;
            border-radius: 12px;
            font-size: 1rem;
        }
        .form-group input:focus {
            border-color: #4361ee;
            outline: none;
        }
        .form-group i {
            position: absolute;
            left: 1.2rem;
            top: 50%;
            transform: translateY(-50%);
            color: #8d99ae;
        }
        .btn {
            width: 100%;
            padding: 1.2rem;
            background: linear-gradient(135deg, #4361ee, #7b2cbf);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1.15rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(67,97,238,0.3);
        }
        .lang-switcher {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .lang-switcher a {
            margin: 0 0.8rem;
            color: #555;
            text-decoration: none;
            font-weight: 500;
            padding: 6px 12px;
            border-radius: 8px;
            transition: all 0.2s;
        }
        .lang-switcher a.active {
            background: #4361ee;
            color: white;
        }
        .note {
            text-align: center;
            margin-top: 2rem;
            color: #8d99ae;
            font-size: 0.95rem;
        }
    </style>
</head>
<body>

<div class="register-box">
    <!-- Перемикач мов -->
    <div class="lang-switcher">
        <?php foreach ($available_langs as $code => $info): ?>
            <a href="?lang=<?= htmlspecialchars($code) ?>" 
               class="<?= $current_lang === $code ? 'active' : '' ?>">
                <?= htmlspecialchars($info['name']) ?> <?= $info['flag'] ?? '' ?>
            </a>
        <?php endforeach; ?>
    </div>

    <div class="logo-circle"><i class="fas fa-house-user"></i></div>
    <h1 class="title"><?= htmlspecialchars($t['header'] ?? 'Реєстрація') ?></h1>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success"><?= $success ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="off">
        <div class="form-group">
            <label for="name"><?= htmlspecialchars($t['name_label'] ?? 'Ім’я') ?></label>
            <i class="fas fa-user"></i>
            <input type="text" id="name" name="name" required 
                   value="<?= htmlspecialchars($form_data['name'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label for="login"><?= htmlspecialchars($t['login_label'] ?? 'Email або телефон') ?></label>
            <i class="fas fa-envelope"></i>
            <input type="text" id="login" name="login" required 
                   placeholder="example@email.com або +4712345678"
                   value="<?= htmlspecialchars($form_data['login'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label for="password"><?= htmlspecialchars($t['password_label'] ?? 'Пароль') ?></label>
            <i class="fas fa-lock"></i>
            <input type="password" id="password" name="password" required>
        </div>

        <div class="form-group">
            <label for="confirm"><?= htmlspecialchars($t['confirm_label'] ?? 'Підтвердіть пароль') ?></label>
            <i class="fas fa-lock"></i>
            <input type="password" id="confirm" name="confirm" required>
        </div>

        <button type="submit" class="btn"><?= htmlspecialchars($t['register_btn'] ?? 'Зареєструватися') ?></button>
    </form>

    <div class="note">
        <?= htmlspecialchars($t['already_have'] ?? 'Вже є акаунт?') ?> 
        <a href="/login.php" style="color:#4361ee; font-weight:600;">
            <?= htmlspecialchars($t['login_link'] ?? 'Увійти') ?>
        </a>
    </div>
</div>

</body>
</html>