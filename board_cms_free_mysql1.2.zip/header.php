<header class="header">
    <div class="container">
        <div class="header-inner">
            <!-- Логотип -->
            <a href="/" class="logo">
                <div class="logo-icon">
                    <i class="fa-solid fa-mountain-sun"></i>
                </div>
                <div class="logo-text">
                    <span class="logo-main"><?= $current_lang === 'no' ? 'Norsk' : ($current_lang === 'en' ? 'Norwegian' : 'Норвезька') ?></span>
                    <span class="logo-sub"><?= $current_lang === 'no' ? 'Oppslagstavle' : ($current_lang === 'en' ? 'Board' : 'Дошка') ?></span>
                </div>
            </a>

            <!-- Десктопна навігація -->
            <nav class="nav-desktop">
                <a href="#robota"><i class="fa-solid fa-briefcase"></i> <?= $current_lang === 'no' ? 'Jobb' : ($current_lang === 'en' ? 'Jobs' : 'Робота') ?></a>
                <a href="#zhytlo"><i class="fa-solid fa-home"></i> <?= $current_lang === 'no' ? 'Bolig' : ($current_lang === 'en' ? 'Housing' : 'Житло') ?></a>
                <a href="#avto"><i class="fa-solid fa-car"></i> <?= $current_lang === 'no' ? 'Bil' : ($current_lang === 'en' ? 'Cars' : 'Авто') ?></a>
                <a href="#posluhy"><i class="fa-solid fa-wrench"></i> <?= $current_lang === 'no' ? 'Tjenester' : ($current_lang === 'en' ? 'Services' : 'Послуги') ?></a>
            </nav>

            <!-- Права частина -->
            <div class="header-right">
                <button class="btn-add" onclick="openModal()">
                    <i class="fas fa-plus-circle"></i> <?= e($texts['add_free']) ?>
                </button>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="/profile.php" class="user-avatar">
                        <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=<?= $_SESSION['user_id'] ?>" alt="Профіль">
                    </a>
                <?php else: ?>
                    <a href="/login.php" class="btn-login"><?= $current_lang === 'no' ? 'Logg inn' : ($current_lang === 'en' ? 'Login' : 'Увійти') ?></a>
                <?php endif; ?>

                <!-- Флаги мов -->
                <div class="lang-switch">
                    <?php foreach ($available_langs as $code => $lang): ?>
                        <a href="?lang=<?= $code ?>" class="lang-flag <?= $current_lang === $code ? 'active' : '' ?>" title="<?= $lang['name'] ?>">
                            <?= $lang['flag'] ?>
                        </a>
                    <?php endforeach; ?>
                </div>

                <!-- Бургер-меню -->
                <button class="burger-btn" aria-label="Меню" aria-expanded="false">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </div>

        <!-- Мобільне меню -->
        <div class="mobile-menu" id="mobileMenu">
            <div class="mobile-menu-inner">
                <button class="mobile-close" aria-label="Закрити меню">
                    <i class="fas fa-times"></i>
                </button>
                <nav class="mobile-nav">
                    <a href="#robota"><i class="fa-solid fa-briefcase"></i> <?= $current_lang === 'no' ? 'Jobb' : ($current_lang === 'en' ? 'Jobs' : 'Робота') ?></a>
                    <a href="#zhytlo"><i class="fa-solid fa-home"></i> <?= $current_lang === 'no' ? 'Bolig' : ($current_lang === 'en' ? 'Housing' : 'Житло') ?></a>
                    <a href="#avto"><i class="fa-solid fa-car"></i> <?= $current_lang === 'no' ? 'Bil' : ($current_lang === 'en' ? 'Cars' : 'Авто') ?></a>
                    <a href="#posluhy"><i class="fa-solid fa-wrench"></i> <?= $current_lang === 'no' ? 'Tjenester' : ($current_lang === 'en' ? 'Services' : 'Послуги') ?></a>
                </nav>
            </div>
        </div>
    </div>
</header>

<style>
    .header {
        background: #ffffff;
        padding: 1rem 0;
        box-shadow: 0 4px 20px rgba(0,0,0,0.06);
        position: sticky;
        top: 0;
        z-index: 1000;
        -webkit-backdrop-filter: blur(10px);
        backdrop-filter: blur(10px);
    }

    .container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 0 1rem;
    }

    .header-inner {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .logo {
        display: flex;
        align-items: center;
        gap: 12px;
        text-decoration: none;
        color: #4361ee;
    }

    .logo-icon {
        width: 50px;
        height: 50px;
        background: linear-gradient(135deg, #4361ee, #ff006e);
        border-radius: 16px;
        display: grid;
        place-items: center;
        color: white;
        font-size: 1.6rem;
    }

    .logo-main {
        font-family: 'Playfair Display', serif;
        font-weight: 800;
        font-size: 1.8rem;
    }

    .logo-sub {
        font-size: 0.9rem;
        opacity: 0.8;
    }

    .nav-desktop {
        display: flex;
        gap: 2rem;
        flex: 1;
        justify-content: center;
    }

    .nav-desktop a {
        color: #2b2d42;
        text-decoration: none;
        font-weight: 600;
        font-size: 1.05rem;
    }

    .header-right {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .btn-add {
        padding: 0.8rem 1.5rem;
        background: #28a745;
        color: white;
        border: none;
        border-radius: 50px;
        font-weight: 600;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(40,167,69,0.25);
    }

    .lang-switch {
        display: flex;
        gap: 0.8rem;
    }

    .lang-flag {
        font-size: 1.6rem;
        cursor: pointer;
    }

    .burger-btn {
        display: none;
        flex-direction: column;
        gap: 5px;
        background: none;
        border: none;
        cursor: pointer;
        padding: 0.5rem;
    }

    .burger-btn span {
        width: 28px;
        height: 3px;
        background: #4361ee;
        border-radius: 2px;
        transition: all 0.3s;
    }

    .burger-btn[aria-expanded="true"] span:nth-child(1) {
        transform: rotate(45deg) translate(7px, 7px);
    }

    .burger-btn[aria-expanded="true"] span:nth-child(2) {
        opacity: 0;
    }

    .burger-btn[aria-expanded="true"] span:nth-child(3) {
        transform: rotate(-45deg) translate(7px, -7px);
    }

    .mobile-menu {
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.6);
        z-index: 999;
        display: none;
        opacity: 0;
        transition: opacity 0.4s ease;
    }

    .mobile-menu.show {
        display: flex;
        opacity: 1;
    }

    .mobile-menu-inner {
        background: white;
        width: 80%;
        max-width: 320px;
        height: 100%;
        margin-left: auto;
        padding: 5rem 2rem 2rem;
        overflow-y: auto;
        transform: translateX(100%);
        transition: transform 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .mobile-menu.show .mobile-menu-inner {
        transform: translateX(0);
    }

    .mobile-close {
        position: absolute;
        top: 1.5rem;
        right: 1.5rem;
        background: none;
        border: none;
        font-size: 2rem;
        color: #4361ee;
        cursor: pointer;
    }

    .mobile-nav a {
        display: block;
        padding: 1.2rem 0;
        color: #2b2d42;
        text-decoration: none;
        font-size: 1.2rem;
        border-bottom: 1px solid #eee;
    }

    @media (max-width: 992px) {
        .nav-desktop { display: none !important; }
        .burger-btn { display: flex !important; }
        .btn-add { font-size: 1rem; padding: 0.7rem 1.2rem; }
        .logo-icon { width: 45px; height: 45px; font-size: 1.4rem; }
        .logo-main { font-size: 1.6rem; }
        .header-right { gap: 0.8rem; }
    }

    @media (max-width: 480px) {
        .btn-add { padding: 0.6rem 1rem; font-size: 0.9rem; }
    }
</style>

<script>
// Бургер-меню
document.addEventListener('DOMContentLoaded', () => {
    const burger = document.querySelector('.burger-btn');
    const menu = document.querySelector('.mobile-menu');
    const closeBtn = document.querySelector('.mobile-close');

    if (burger) {
        burger.addEventListener('click', () => {
            const expanded = burger.getAttribute('aria-expanded') === 'true';
            burger.setAttribute('aria-expanded', !expanded);
            menu.classList.toggle('show');
            document.body.style.overflow = expanded ? '' : 'hidden';
        });

        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                burger.setAttribute('aria-expanded', 'false');
                menu.classList.remove('show');
                document.body.style.overflow = '';
            });
        }

        menu.addEventListener('click', (e) => {
            if (e.target === menu) {
                burger.setAttribute('aria-expanded', 'false');
                menu.classList.remove('show');
                document.body.style.overflow = '';
            }
        });
    }
});
</script>