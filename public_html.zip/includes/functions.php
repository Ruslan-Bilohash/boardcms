<?php
// includes/functions.php
// Набір корисних функцій для роботи з оголошеннями та новинами
// Оновлено: 30 грудня 2025 року
// Автор: Ruslan Bilohash

/**
 * Отримує всі схвалені оголошення з папки ads/
 * 
 * @return array Масив оголошень з доданим полем 'id' (назва файлу)
 */
function getApprovedAds() {
    $ads = [];
    $dir = __DIR__ . '/../ads/';

    if (!is_dir($dir)) {
        return $ads; // Папки немає — повертаємо порожній масив
    }

    $files = glob($dir . '*.json');
    if ($files === false) {
        return $ads; // Помилка читання директорії
    }

    foreach ($files as $file) {
        $json = @file_get_contents($file);
        if ($json === false) {
            continue; // Не вдалося прочитати файл
        }

        $ad = json_decode($json, true);
        if (!is_array($ad)) {
            continue; // Некоректний JSON
        }

        // Показуємо тільки схвалені
        if (($ad['status'] ?? 'pending') === 'approved') {
            $ad['id'] = basename($file);
            $ads[] = $ad;
        }
    }

    // Сортування: новіші зверху
    usort($ads, function ($a, $b) {
        return strcmp($b['created_at'] ?? '1970-01-01T00:00:00Z', $a['created_at'] ?? '1970-01-01T00:00:00Z');
    });

    return $ads;
}

/**
 * Отримує всі новини/події з папки news/
 * 
 * @return array Масив новин з полем 'id'
 */
function getNews() {
    $news = [];
    $dir = __DIR__ . '/../news/';

    if (!is_dir($dir)) {
        return $news;
    }

    $files = glob($dir . '*.json');
    if ($files === false) {
        return $news;
    }

    foreach ($files as $file) {
        $json = @file_get_contents($file);
        if ($json === false) {
            continue;
        }

        $item = json_decode($json, true);
        if (!is_array($item)) {
            continue;
        }

        $item['id'] = basename($file);
        $news[] = $item;
    }

    // Сортування: новіші зверху
    usort($news, function ($a, $b) {
        return strcmp($b['created_at'] ?? '1970-01-01T00:00:00Z', $a['created_at'] ?? '1970-01-01T00:00:00Z');
    });

    return $news;
}

/**
 * Зберігає оголошення у JSON-файл (резервне збереження)
 * 
 * @param array $data Дані оголошення
 * @return string|bool Ім'я файлу при успіху, false при помилці
 */
function saveAdToJson($data) {
    $ads_dir = __DIR__ . '/../ads/';
    if (!is_dir($ads_dir)) {
        if (!mkdir($ads_dir, 0755, true)) {
            error_log("Не вдалося створити директорію ads/");
            return false;
        }
    }

    $timestamp = date('Ymd_His');
    $random = substr(md5(uniqid(microtime(true), true)), 0, 6);
    $filename = $ads_dir . $timestamp . '_' . $random . '.json';

    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if (file_put_contents($filename, $json) === false) {
        error_log("Не вдалося записати файл: $filename");
        return false;
    }

    return basename($filename);
}

/**
 * Перевіряє, чи існує користувач за логіном (email/телефон)
 * 
 * @param string $login Email або телефон
 * @return bool true — якщо існує
 */
function userExists($login) {
    // Якщо використовуєте БД — додайте запит
    // Якщо JSON — перевірка в data/users.json
    $users_file = __DIR__ . '/../data/users.json';
    if (!file_exists($users_file)) {
        return false;
    }

    $users = json_decode(file_get_contents($users_file), true) ?? [];
    foreach ($users as $user) {
        if ($user['login'] === $login) {
            return true;
        }
    }
    return false;
}