<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// index.php — головна сторінка (повна версія, 29.12.2025)

require_once 'config.php';
require_once 'functions.php';
?>

<!DOCTYPE html>
<html lang="<?= $current_lang ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Безкоштовна дошка оголошень для українців у Норвегії — робота, житло, авто, послуги, події">

    <title><?= e($texts['site_title']) ?> — <?= e($texts['site_subtitle']) ?></title>

    <!-- Шрифти -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700;800&family=Playfair+Display:wght@700;800&display=swap" rel="stylesheet">

    <!-- Іконки -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5n/N0Xv4w=" crossorigin=""/>

    <!-- Головний CSS -->
    <link rel="stylesheet" href="/css/main.css?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/css/main.css') ?: time() ?>">

    <!-- Cookie Consent -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.js" defer></script>

    <script>
    window.addEventListener("load", function(){
        window.cookieconsent.initialise({
            "palette": { "popup": { "background": "#1e1e2f" }, "button": { "background": "#28a745" } },
            "position": "bottom-left",
            "content": {
                "message": "Ми використовуємо cookies для покращення роботи сайту",
                "dismiss": "Прийняти",
                "link": "Детальніше",
                "href": "/personvern.php"
            }
        });
    });
    </script>
</head>
<body>

<?php include 'header.php'; ?>

<div class="banner" style="background:#ff6b35; color:white; text-align:center; padding:14px; font-weight:bold; font-size:18px;">
    Сайт у розробці — вже скоро на повну потужність!
</div>

<div class="container">
    <?php include 'map-section.php'; ?>
    <?php include 'news-section.php'; ?>
    <?php include 'ads-section.php'; ?>

<div class="tiles" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 20px; margin: 50px 0;">
    <a href="#" class="tile" style="background: white; padding: 28px 15px; text-align: center; border-radius: 16px; text-decoration: none; color: #333; box-shadow: 0 6px 20px rgba(0,0,0,0.1); transition: 0.3s;">
        <i class="fa-solid fa-wrench" style="font-size: 48px; margin-bottom: 15px; color: #4361ee;"></i><br>Майстри
    </a>
    <a href="#" class="tile">
        <i class="fa-solid fa-scissors" style="font-size: 48px; margin-bottom: 15px; color: #ff006e;"></i><br>Краса
    </a>
    <a href="#" class="tile">
        <i class="fa-solid fa-car-side" style="font-size: 48px; margin-bottom: 15px; color: #06d6a0;"></i><br>Авто
    </a>
    <a href="#" class="tile">
        <i class="fa-solid fa-house-chimney" style="font-size: 48px; margin-bottom: 15px; color: #f39c12;"></i><br>Нерухомість
    </a>
    <a href="#" class="tile">
        <i class="fa-solid fa-plane-departure" style="font-size: 48px; margin-bottom: 15px; color: #8e44ad;"></i><br>Подорожі
    </a>
    <a href="#" class="tile">
        <i class="fa-solid fa-location-dot" style="font-size: 48px; margin-bottom: 15px; color: #e74c3c;"></i><br>Коло мене
    </a>
</div>
<button class="btn-add" onclick="openModal()">
    <i class="fas fa-plus-circle"></i> <?= e($texts['add_free']) ?>
</button>

<!-- Buy Me a Coffee віджет -->
<script data-name="BMC-Widget" data-cfasync="false" src="https://cdnjs.buymeacoffee.com/1.0.0/widget.prod.min.js" data-id="bilohash" data-description="Support me on Buy me a coffee!" data-message="Дякую за підтримку! ❤️" data-color="#FF813F" data-position="Right" data-x_margin="18" data-y_margin="18"></script>

<?php include 'modal-add.php'; ?>
<?php include 'footer.php'; ?>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const map = L.map('map').setView([64.686313, 12.013787], 5);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

const places = <?= json_encode(array_map(function($ad) {
    return [
        'title'   => $ad['title'] ?? 'Оголошення',
        'city'    => $ad['city'] ?? '',
        'price'   => $ad['price'] ?? '',
        'photo'   => $ad['photo'] ?? null,
        'lat'     => $ad['lat'] ?? null,
        'lng'     => $ad['lng'] ?? null,
        'contact' => $ad['contact'] ?? ''
    ];
}, getApprovedAds())) ?>;

places.forEach(p => {
    if (p.lat && p.lng) {
        let popup = `<b>${p.title}</b><br>${p.city}<br><b>Ціна:</b> ${p.price}`;
        if (p.contact) popup += `<br><b>Контакт:</b> ${p.contact}`;
        if (p.photo) popup += `<br><img src="${p.photo}" style="max-width:220px;border-radius:8px;margin-top:8px;">`;
        L.marker([p.lat, p.lng]).addTo(map).bindPopup(popup);
    }
});

function openModal(){document.getElementById('addModal').style.display='block'}
function closeModal(){document.getElementById('addModal').style.display='none'}
window.onclick = e => { if(e.target.classList.contains('modal')) closeModal() }
</script>
<!-- Модальне сповіщення про успіх -->
<div id="successModal" class="modal" style="display:none; position:fixed; z-index:3000; left:0; top:0; width:100%; height:100%; background:rgba(0,0,0,0.6); align-items:center; justify-content:center;">
    <div style="background:white; border-radius:24px; padding:3rem; max-width:480px; width:90%; text-align:center; box-shadow:0 20px 60px rgba(0,0,0,0.3); transform:scale(0.8); opacity:0; transition:all 0.4s ease;">
        <div style="font-size:4.5rem; color:#28a745; margin-bottom:1rem; animation: bounce 1s ease;">
            <i class="fas fa-check-circle"></i>
        </div>
        <h2 style="font-size:1.8rem; color:#2b2d42; margin:0 0 1rem;">Успіх!</h2>
        <p id="successMessage" style="color:#555; font-size:1.1rem; margin-bottom:2rem; line-height:1.5;">
            Оголошення додано безкоштовно!<br>Після модерації воно з’явиться на сайті та карті.
        </p>
        <button onclick="document.getElementById('successModal').style.display='none'" style="padding:0.9rem 2.5rem; background:#28a745; color:white; border:none; border-radius:12px; font-size:1.1rem; font-weight:600; cursor:pointer; transition:all 0.3s;">
            Закрити
        </button>
    </div>
</div>

<style>
    @keyframes bounce {
        0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
        40% { transform: translateY(-20px); }
        60% { transform: translateY(-10px); }
    }
</style>

<script>
// Функція показу модального сповіщення
function showSuccess(message = "Дія успішно виконана!") {
    document.getElementById('successMessage').textContent = message;
    const modal = document.getElementById('successModal');
    modal.style.display = 'flex';
    
    // Анімація появи
    setTimeout(() => {
        modal.querySelector('div').style.transform = 'scale(1)';
        modal.querySelector('div').style.opacity = '1';
    }, 10);
}
</script>
</body>
</html>